
module.exports = function (app) {
  //connect to database using details in the dbconfig file
  const mongoose = require("../config/dbconfig");

  //create an instance of user based on model
  const User = require("../models/user");
  const Observation = require("../models/observation");
  const Payment = require("../models/payment");
  const Message = require("../models/message");
  const Response = require("../models/responses");

  //authentication middleware
  const passport = require("passport");
  
  //create a strategy
  passport.use(User.createStrategy());
  passport.serializeUser(User.serializeUser());
  passport.deserializeUser(User.deserializeUser());

  checkAuth = (req, res, next) => {
    //passpport adds this to the request objects
    if (req.isAuthenticated()) {
      return next();
    }
    res.redirect("/userpages/login");
  };

  //------------------------------------home page-------------------------------------------------------------
  app.get("/", (req, res) => {
    //render home page
    res.render("../menu");
  });


  //====================================sign up page===========================================================

  app.get("/userpages/signup", (req, res) => {
    
    //to render the signup page
    res.render("../userpages/signup");
  });


  app.post("/userpages/signup", (req, res) => {
    //accept details through post method and create document
    console.log(req.body)
      User.register(
        new User({
            userforename : req.body.userforename,
            usersurname : req.body.usersurname,
            username: req.body.username,
        
            usergender: req.body.usergender,
            accountType: req.body.accountType,
            accountRole: req.body.accountRole,
            userDOB : req.body.userDOB,
            terms : req.body.terms,
            
         }),
        req.body.password,
        

        function (err, user) {
          if (err) {
            console.log(err);
            return res.render("../userpages/signup");
          } else {
            passport.authenticate("local")(req, res, function () {
              console.log(`Authenticated at signup: ${req.isAuthenticated()}`);
              res.redirect("/userpages/login");
              
            });
          }
        }
      );
  });
//======================================= Login page==================================================

app.get("/userpages/login", (req, res) => {
  console.log(`Authenticated at login: ${req.isAuthenticated()}`);
  //render login page
  res.render("../userpages/login");
});

app.post("/userpages/login", (req, res)=>{
  User.findOne({username: req.body.username}, function(err, username){
    if(err) {
      console.log(err);
      return res.render("../userpages/login");
    }else{
      passport.authenticate("local")(req, res, function (err){
        console.log(username);
        if(username.accountRole == "Client" & username. accountStatus == "active"){
          console.log(`Authenticated: ${req.isAuthenticated()}`);
          //add return 
          return res.redirect("/userpages/client");
          
        }
        if(username. accountStatus == "Suspended"){
          console.log(`Authenticated: ${req.isAuthenticated()}`);
          
          res.redirect("/userpages/login");
          
        } else{
          console.log(`Authenticated: ${req.isAuthenticated()}`);
          res.redirect("/supports");
        }
      })
    }
  })
})

/*
app.post( "/userpages/login", (req, res) =>{
    User.findOne({username:req.body.username}, function(err, username){
      if(err) {
        console.log(err);
        return res.render("../userpages/login");
        
      }
      if(username.accountRole == "Client" & username. accountStatus == "active"){

        passport.authenticate("local", {
          successRedirect: "/userpages/client",
          failureRedirect: "/userpages/login",
        })
      } if(username.accountRole == "Support"){

        passport.authenticate("local", {
          successRedirect: "/userpages/support",
          failureRedirect: "/userpages/login",
        })
      }
      
    
  
 
  
  });

  
});
*/
//===================================client page======================================================
  //put checkAuthh back
  app.get("/userpages/client", checkAuth, (req, res) => {
    console.log(`Authenticated at client:${req.isAuthenticated()}`);
    Observation.find({}, function (err, findAllUsersQry) {
      if (err) throw err;
      //render signup page
      res.render("../userpages/client", { observations: findAllUsersQry });
      console.log("User has been successfully Logged In");
    });
  });

  app.post("/observations/queryob", (req, res) => {
    //query all users' documents
    Observation.findById(req.body._id, function (err, findAllUsersQry) {
      if (err) throw err;
      //render page with form to accept choice for one user
      res.render("../observations/queryob", { observations: findAllUsersQry });
    });
  });
//==============================view account settings page======================================================

app.get("/account_settings", (req, res) => {
  //render page with form to indert one user document
  res.render("../userpages/account_settings");
});

//========================client view his account========================================
/*app.get("/account_settings/getaccount", (req, res) => {
  //query all users' documents
  User.findOne({_id:req.body._id}, function (err, findAllUsersQry) {
    if (err) throw err;
    //render page with all users' document
    res.render("../account_settings/getaccount", {account_settings: findAllUsersQry});
  });
});
*/
app.get("/account_settings/getaccount", (req, res) => {
  //query all users' documents
  User.findById({_id:req.user._id}, function (err, findAllUsersQry) {
    if (err) throw err;
    //render page with all users' document
    res.render("../account_settings/getaccount", {accounts: findAllUsersQry});
  });
});

//=============================client update his account===================================
app.get("/account_settings/updateaccount", (req, res) => {
  //query all users documents
  User.findById({_id:req.user._id}, function (err, findAllUsersQry) {
    if (err) throw err;
    //render page with form to accept choice for update
    res.render("../account_settings/updateaccount", { accounts: findAllUsersQry,});
  });
});

app.post("/account_settings/updateaccount", (req, res) => {
  console.log(req.body);
  //update details with data sent via form
  User.findOneAndUpdate(
    { _id: req.user._id },
    {
      $set: {
        userforename: req.body.userforename,
        usersurname: req.body.usersurname,
        useremail: req.body.useremail,
        userDOB: req.body.userDOB,
      },
    },
    null,
    function (err) {
      if (err) throw err;
      //show effect of update by redirecting to show all documents
      res.redirect("/account_settings/getaccount");
    }
  );
});
//====================================Subscription page==================================
app.get("/userpages/subscription", (req, res) =>{
//render the subscription page
res.render("../userpages/subscription");
});

app.post("/userpages/subscription", (req, res)=>{
//accept details through post method and create document
console.log(req.body);
Payment.create(req.body, function (err){
    if (err) throw err;
    res.redirect("/userpages/client");
    
});


});

//===============================observation page==========================================================
  app.get("/observation", checkAuth, (req, res) => {
    console.log(`Authenticated at observation: ${req.isAuthenticated()}`);
    //render page with form to indert one user document
    res.render("../userpages/observation");
  });
  //==============================add observation==============================================
  app.get("/observations/addob", (req, res) => {
    //render page with form to indert one user document
    res.render("../observations/addob");
  });

  app.post("/observations/addob", (req, res) => {
    console.log(req.body)
    //accept details through post method and create document
    Observation.create(req.body, function (err) {
      if (err) throw err;
      res.redirect("../observations/getob");
    });
  });
  //======================== view observations======================================================
  app.get("/observations/getob", (req, res) => {
    //query all users' documents
    Observation.find({}, function (err, findAllUsersQry) {
      if (err) throw err;
      //render page with all users' document
      res.render("../observations/getob", { observations: findAllUsersQry });
    });
  });
//=========================get exact  observation=============================================
app.get("/observations/queryobbytitle", (req, res) => {
  //query all users' documents
  Observation.find({}, function (err, findAllUsersQry) {
    if (err) throw err;
    //render page with form to accept choice for one user
    res.render("../observations/queryobbytitle", {
      observations: findAllUsersQry,
    });
  });
});

app.post("/observations/queryob", (req, res) => {
  //query document based on specfic id passed through post method
  Observation.findById(req.body._id, function (err, findOneUserQry) {
    if (err) throw err;
    //render form with document relating to specific user
    res.render("../observations/queryob", { observation: findOneUserQry });
  });
});

//===========================delete observations=========================================================
app.get("/observations/deleteobbyid", (req, res) => {
  //query all users documents
  Observation.find({}, function (err, findAllUsersQry) {
    if (err) throw err;
    //render page with form to accept choice for document deletion
    res.render("../observations/deleteobbyid", {
      observations: findAllUsersQry,
    });
  });
});

app.post("/observations/deleteob", (req, res) => {
  //delete document based on specific id passed through post method
  Observation.deleteOne({ _id: req.body._id }, function (err) {
    if (err) throw err;
    //show effect of deletion by redirecting to show all documents
    res.redirect("/observations/getob");
  });
});




//=======================================Message===================================================================
app.get("/userpages/message", (req, res) =>{
  //render the message page
  res.render("../userpages/message");
});
app.post("/userpages/message", (req, res)=>{
  console.log(req.body)
  //accept details through post method and create document
  Message.create(req.body, function (err){
      if (err) throw err;
      res.redirect("/account_settings/getmessage");
  });


});

app.get("/account_settings/getmessage", (req, res) => {
  //query all users' documents
  Message.find({}, function (err, findAllUsersQry) {
    if (err) throw err;
    //render page with all users' document
    res.render("../account_settings/getmessage", { messages: findAllUsersQry });
  });
});

//=======================================Reply===================================================================
app.get("/userpages/response", (req, res) =>{
  //render the message page
  res.render("../userpages/response");
});
app.post("/userpages/response", (req, res)=>{
  console.log(req.body)
  //accept details through post method and create document
  Response.create(req.body, function (err){
      if (err) throw err;
      res.redirect("/account_settings/getmessage");
  });


});

app.get("/account_settings/getmessage", (req, res) => {
  //query all users' documents
  Response.find({}, function (err, findAllUsersQry) {
    if (err) throw err;
    //render page with all users' document
    res.render("../account_settings/getmessage", { messages: findAllUsersQry });
  });
});

 


//=================================== support page==========================================================

  app.get("/supports", checkAuth, (req, res) => {
    //render page with form to indert one user document
    res.render("../userpages/support");
  });
  
//========================Support view  client===================================================================
   app.get("/supports/getclient", (req, res) => {
    //query all users' documents
    User.find({}, function (err, findAllUsersQry) {
      if (err) throw err;
      //render page with all users' document
      res.render("../supports/getclient", {
        account_settings: findAllUsersQry,
      });
    });
  });

  //================================ update client account============================================================
  app.get("/supports/updateclient", (req, res) => {
    //query all users documents
    User.find({}, function (err, findAllUsersQry) {
      if (err) throw err;
      //render page with form to accept choice for update
      res.render("../supports/updateclient", { account_settings: findAllUsersQry,});
    });
  });

  app.post("/supports/updateclient", (req, res) => {
    console.log(req.body)
    //update details with data sent via form
    User.findOneAndUpdate(
      { _id: req.body._id },
      {
        $set: {
          userforename: req.body.userforename,
          usersurname: req.body.usersurname,
          useremail: req.body.useremail,
          userDOB: req.body.userDOB,
          accountStatus: req.body.accountStatus,
        },
      },
      null,
      function (err) {
        if (err) throw err;
        //show effect of update by redirecting to show all documents
        res.redirect("/supports/getclient");
      }
    );
  });
  //=========================suppport delete client===================================
  app.get("/supports/deleteuserbyid", (req, res) => {
    //query all users documents
    User.find({}, function (err, findAllUsersQry) {
      if (err) throw err;
      //render page with form to accept choice for document deletion
      res.render("../supports/deleteuserbyid", {
        account_settings: findAllUsersQry,
      });
    });
  });

  app.post("/supports/deleteuser", (req, res) => {
    console.log(req.body)
    //delete document based on specific id passed through post method
    User.deleteOne({ _id: req.body._id }, function (err) {
      if (err) throw err;
      //show effect of deletion by redirecting to show all documents
      res.redirect("/supports/getclient");
    });
  });

  //=================================support add support===========================================================
  app.get("/supports/addsupport", (req, res) => {
    //render page with form to indert one user document
    res.render("../supports/addsupport");
  });

  app.post("/supports/signup", (req, res) => {
    console.log(req.body)
      User.register(
        new User({
            userforename : req.body.userforename,
            usersurname : req.body.usersurname,
            username: req.body.username,
        
            usergender: req.body.usergender,
            accountType: req.body.accountType,
            accountRole: req.body.accountRole,
            userDOB : req.body.userDOB,
            terms : req.body.terms,
            
         }),
        req.body.password,
        

        function (err, user) {
          if (err) {
            console.log(err);
            return res.render("../supports/addsupport");
          } else {
            passport.authenticate("local")(req, res, function () {
              console.log(`Authenticated at signup: ${req.isAuthenticated()}`);
              res.redirect("../userpages/support");
              
            });
          }
        }
      );
  });

 

  //======================= support view particular client==========================================================
  app.get("/supports/queryuserbyid", (req, res) => {
    //query all users' documents
    User.find({}, function (err, findAllUsersQry) {
      if (err) throw err;
      //render page with form to accept choice for one user
      res.render("../supports/queryuserbyid", {
        account_settings: findAllUsersQry,
      });
    });
  });

  app.post("/supports/queryuser", (req, res) => {
    //query document based on specfic id passed through post method
    User.findById(req.body._id, function (err, findOneUserQry) {
      if (err) throw err;
      //render form with document relating to specific user
      res.render("../supports/queryuser", { account_settings: findOneUserQry });
    });
  });
//===========================================signout=====================================================================
app.get("/userpages/signout", (req, res)=>{
  console.log(`Authenticated at logout: ${req.isAuthenticated()}`);
  req.logout();
  console.log("User Has Been Logged Out");
  console.log(`Authenticated at logout: ${req.isAuthenticated()}`);
  res.redirect("/userpages/login");
});

 
};
