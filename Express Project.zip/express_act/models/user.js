const mongoose = require('mongoose');

passportLocalMongoose = require("passport-local-mongoose");



//define a schema for user
const UserSchema = new mongoose.Schema({
    usertitle : String,
    userforename : String,
    usersurname : String,
    username:{type: String, unique: true},
    password: String,
    usergender: String,
    accountType: String,
    accountRole: String,
    accountStatus: {type: String, default:"active"},
    userDOB : Date,
    terms : { type: Boolean, default: false},
    
    
});

UserSchema.plugin(passportLocalMongoose);

//instantiate an instance of the user model
const User = mongoose.model('sysusers', UserSchema);

//Export function to create user model class
module.exports = mongoose.model('sysusers', UserSchema);