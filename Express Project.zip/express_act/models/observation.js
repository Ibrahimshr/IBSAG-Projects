const mongoose = require('mongoose');

//define a schema for support
const ObSchema = new mongoose.Schema({
    username : String,
    category : String,
    title : String,
    galactic: String,
    coordinate: String,
    description: String,
    avatar: String,
    analyses: String,
});

//instantiate an instance of the user model
const Observation = mongoose.model('observations', ObSchema);

//Export function to create user model class
module.exports = mongoose.model('observations', ObSchema);