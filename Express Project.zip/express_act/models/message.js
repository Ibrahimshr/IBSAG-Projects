const mongoose = require('mongoose');

//define a schema for support
const SupportSchema = new mongoose.Schema({
    userforename : String,
    usersurname : String,
    username:{type: String, unique: true},
    message : String,
    
});



//instantiate an instance of the user model
const Message = mongoose.model('messageuser', SupportSchema);

//Export function to create user model class
module.exports = mongoose.model('messageuser', SupportSchema);