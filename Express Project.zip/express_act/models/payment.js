const mongoose = require('mongoose');

const bcrypt = require("bcrypt");
const saltRounds = 10;
//define a schema for user
const PaymentSchema = new mongoose.Schema({
    cardtype: String,
    cardname: String,
    cardnumber: String,
    expmonth: Number,
    expyear: Number,
    cvv: String,
    
   
});
//Hashing the card number 
PaymentSchema.pre('save', function(next){
    var num = this;
    //hashes the card number if it has been modified
    if(!num.isModified('cardnumber')) return next();
    //create the salt
    bcrypt.genSalt(saltRounds, function(err, salt) {
        if(err) return next(err);
        //hash the card number using the salt
        bcrypt.hash(num.cardnumber, salt, function(err, hash){
            if (err) return next(err);
            num.cardnumber = hash;
            next();
            
        });
    });
});

//Hashing the card cvv 
PaymentSchema.pre("save", function(next){
    var ncvv = this;
    //hashes the card cvv if it has been modified
    if(!ncvv.isModified("cvv")) return next();
    //create the salt
    bcrypt.genSalt(saltRounds, function(err, salt) {
        if(err) return next(err);
        //hash the card cvv using the salt
        bcrypt.hash(ncvv.cvv,salt, function(err, hash){
            if (err) return next(err);
            ncvv.cvv = hash;
            next();
        });
    });
});
//instantiate an instance of the user model
const Payment = mongoose.model('paymentDB', PaymentSchema);

//Export function to create user model class
module.exports = mongoose.model('paymentDB', PaymentSchema);

