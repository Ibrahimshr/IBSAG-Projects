const express = require('express')
const app = express()
const port = 3000 


//directs express to static asserts
app.use(express.static('public'))
//body-parser middleware
//enables transfer of post data from html forms
app.use(express.urlencoded({extend: true}));

//----set ejs to generate dynamic html pages----------------
app.set('view engine', 'ejs');
//if i have error i should comeback here change it users
app.set('views', [__dirname + "/views", __dirname + "/views/userpages"]);

//session-based authorisation middleware
const session = require("express-session");
app.use(
    session({
        secret:"randomisedtext",
        resave:false,
        saveUninitialized:false,
    })
);

//authentication middleware
const passport = require("passport");
app.use(passport.initialize());
app.use(passport.session());

/*routes relating to http://localhost:3000/users/have been stored
separately for separation of concerns*/
require('./routes/userroustes')(app);






app.listen(port, () =>{
    console.log(`App listening at http://localhost: ${port}`)
})