const mongoose = require('mongoose');
const mongoDB = 'mongodb+srv://mongopro:ID8I5e2aWcCwQ4rM@cluster0.27ugm.mongodb.net/Project?retryWrites=true&w=majority';
mongoose.connect(mongoDB,{useNewUrlParser:true,useUnifiedTopology:true});

const db = mongoose.connection;
db.on('error',console.error.bind(console,'connection error:'));
db.once('open',function(){
    console.log("Connected successfully to MongoDB!")
});
module.exports = mongoose;